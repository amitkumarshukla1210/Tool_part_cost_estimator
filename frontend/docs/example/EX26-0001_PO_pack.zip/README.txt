Design to Cost - PO pack for EX26-0001 · L mounting bracket
Made 2026-10-26

01_part   part 3D model (master) and part drawing
02_tool   tool cost sheets and concept drawings per stage / mould, blank and strip layout
03_cost   RM and part cost sheets

Drawings are CONCEPT layouts for quotation and PO reference; the 3D model is the master for geometry.
