Design to Cost - tool design release for EX26-0001 L mounting bracket
Made 2026-10-26

Per tool: 3D/ assembly STEP and one STEP per part; 2D/PDF the drawing set (assembly + every made part);
2D/DXF the assembly and every made part at 1:1 with title block and logo; BOM (Excel).

First-cut design made by the rules in Master data (Mould & die database -> Design rules): the tool designer
checks and completes it before release for manufacture.

T01_Die_1__Blanking: Die 1: Blanking, 15 items, shut height 186 mm
    - Closed (bottom of stroke): shut height 186.0 mm; strip 46.0 mm wide between the stock guides.
    - Press PRESS-100 for 61.7 t.
T02_Die_2__Piercing: Die 2: Piercing, 14 items, shut height 186 mm
    - Closed (bottom of stroke): shut height 186.0 mm; blank located in the nest plate.
    - Press PRESS-100 for 13.5 t.
T03_Die_3__Bending__V: Die 3: Bending (V), 9 items, shut height 194.6 mm
    - Closed (bottom of stroke): shut height 194.6 mm; blank located by gauge pins at the end of the far leg.
    - Press PRESS-100 for 0.6 t.