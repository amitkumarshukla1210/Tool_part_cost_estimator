Design to Cost - tool design release for EX26-0002 plastic_cover
Made 2026-10-26

Per tool: 3D/ assembly STEP and one STEP per part; 2D/PDF the drawing set (assembly + every made part);
2D/DXF the assembly and every made part at 1:1 with title block and logo; BOM (Excel).

First-cut design made by the rules in Master data (Mould & die database -> Design rules): the tool designer
checks and completes it before release for manufacture.

T01_Mould___1_cavity: Mould · 1 cavity, 17 items, shut height 250 mm
    - Cavity and core = part × 1.005 (shrinkage 0.5 %).
    - Gate, runner, vents, slides and lifters: to be added by the mould designer (see the concept analysis).
    - Core formed by the region the part encloses (inside of the part).
    - Cooling: 4 channel(s) Ø8 per cavity in the inserts, 20 mm from the moulding faces.
    - Mould height 250 mm, 1 cavity, opening stroke ≥ 80 mm.